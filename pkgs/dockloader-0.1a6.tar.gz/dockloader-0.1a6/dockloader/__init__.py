# coding:utf-8

from .parser import Tag
from .parser import TagConfig
